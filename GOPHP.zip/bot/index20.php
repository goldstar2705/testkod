<?php
ob_start();
define('API_KEY','**TOKEN**');
echo file_get_contents("https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);

function bot($method, $datas = [])
  {
  $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
  $res = curl_exec($ch);
  if (curl_error($ch))
    {
    var_dump(curl_error($ch));
    }
    else
    {
    return json_decode($res);
    }
  }

$update = json_decode(file_get_contents('php://input'));
$update = json_decode(file_get_contents('php://input'));
$data = $update->callback_query->data;
$cid2 = $update->callback_query->message->chat->id; 
$cqid = $update->callback_query->id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id = $update->callback_query->message->message_id;
$reply = $update->message->reply_to_message;
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$from_id = $message->from->id;
$sudo = file_get_contents("ids.txt");
$u = explode("\n",file_get_contents("memb.txt"));
$c = count($u)-1;
$modxe = file_get_contents("usr.txt");
$chs = file_get_contents('ch.txt');
$buy = file_get_contents("buy.txt");
$admin = 621617473;
$username = $update->message->from->username;
$reply = $message->reply_to_message->message_id;
$list = file_get_contents("blocklist.txt");
$rep = $message->reply_to_message->forward_from; 
$id = $rep->id; 
$ch = "@$chs";
$chs = "@PHP_OWN";
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@PHP_OWN&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"Siz birinchi kanalga obuna bo'lishingiz kerak ⚜️
◼ Siz Kanalga obuna bo'ling va keyin /start ni yuboring,
 - Kanal @PHP_OWN • ",

]);
  bot("sendmessage",[
    "chat_id"=>$sudo,
    "text"=>" A'zo kanali ga obuna bo'ldi
- obuna bo'lgan a'zoning ma'lumotlari;

• Ism; $name
• Useri; $from_id
• ID; @$username
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎ ",
    ]);
    die('ban');
}

$ebu = explode("\n",$list);
if(in_array($from_id,$ebu)){
    bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"▪ Siz bot egasi tomonidan bloklangansiz,
▫ ️ Siz botdan foydalana olmaysiz, 🚫
 ﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[Kanalimiz🌐](https://t.me/PHP_OWN)
 ",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
      ]);
    
}

function wr($type,$text,$id){
  $str = str_split(strtolower($text));
  switch ($type) {
case '1':
      $url = 'https://ddyd.000webhostapp.com/khz/';
            case '2':
      $url = 'https://iuytiuyt.000webhostapp.com/r/xn/';
            case '3':
      $url = 'https://iuytiuyt.000webhostapp.com/r/neon';
      
      break;
      
      break;
      break;
      case '4':
      $url = 'https://ddyd.000webhostapp.com/phoz1/';
      break;
      case '5':
      $url = 'https://ddyd.000webhostapp.com/klx7/';
      break;
      case '6':
      $url = 'https://oa-74.000webhostapp.com/halkat/';
      break;
case '7':
      $url = 'https://iuytiuyt.000webhostapp.com/r/book/';
         break;
      break;
      case '8':
      $url = 'https://oa-74.000webhostapp.com/lmarsase/';
      break;
      case '9':
      $url = 'https://oa-74.000webhostapp.com/kears/';
      break; 
      case '10':
      $url = 'https://ddyd.000webhostapp.com/psz/';
      break;
      case '11':
      $url = 'https://oa-74.000webhostapp.com/jooklet/';
      break;
      case '12':
      $url = 'https://oa-74.000webhostapp.com/ward/';
      break;
      case '13':
      $url = 'http://devel-point.ga/cand/photos3z/';
      break;
      case '14':
      $url = 'https://ddyd.000webhostapp.com/lmko7/';
      break;
      case '15':
      $url = 'https://oa-74.000webhostapp.com/kletr/';
      break;
      case '16':
      $url = 'https://ddyd.000webhostapp.com/photo5t/';
      break;
      case '17':
      $url = 'https://ddyd.000webhostapp.com/rml7e/';
      break;
      case '18':
      $url = 'https://ddyd.000webhostapp.com/alwu3/';
      break;
      case '19':
      $url = 'https://oa-74.000webhostapp.com/shame/';
      break;
      case '20':
      $url = 'https://bl-saadmohammed.000webhostapp.com/nj3/';
      break;
      case '21':
      $url = 'https://sd-saadmohammed.000webhostapp.com/wae/';
      break;
      case '22':
      $url = 'https://bl-saadmohammed.000webhostapp.com/ke3/';
      break;
      case '23':
      $url = 'https://bl-saadmohammed.000webhostapp.com/hl1o/';
      break;
      case '24':
      $url = 'https://bl-saadmohammed.000webhostapp.com/hl2o/';
      break;
      case '25':
      $url = 'https://bl-saadmohamm٨ed.000webhostapp.com/w1ae/';
      break;
      case '26':
      $url = 'https://bl-saadmohammed.000webhostapp.com/w2ae/';
      break;
      case '27':
      $url = 'https://bl-saadmohammed.000webhostapp.com/w3ae/';
      break;
      case '28':
      $url = 'https://bl-saadmohammed.000webhostapp.com/smv/';
      break;
      case '29':
      $url = 'https://bl-saadmohammed.000webhostapp.com/banz/';
      break;
      case '30':
      $url = 'https://bl-saadmohammed.000webhostapp.com/kto0/';
      break;
      case '31':
      $url = 'https://bl-saadmohammed.000webhostapp.com/d3zh/';
      break;
      case '32':
      $url = 'https://bl-saadmohammed.000webhostapp.com/to/';
      break;
      case '33':
      $url = 'https://bl-saadmohammed.000webhostapp.com/nj0/';
      break;
      case '34':
      $url = 'https://bl-saadmohammed.000webhostapp.com/hdk1/';
      break;
      case '35':
      $url = 'https://bl-saadmohammed.000webhostapp.com/zjp/';
      break;
      case '36':
      $url = 'https://bl-saadmohammed.000webhostapp.com/nfk1/';
      break;
      case '37':
      $url = 'https://bl-saadmohammed.000webhostapp.com/w4ae/';
      break;
      case '38':
      $url = 'https://denel.000webhostapp.com/jde0/';
      break;
      case '39':
      $url = 'https://bl-saadmohammed.000webhostapp.com/w5ae/';
      break;
      case '40':
      $url = 'https://denel.000webhostapp.com/w6ae/';
      break;
      case '41':
      $url = 'https://oa-74.000webhostapp.com/carton/';
      break;
      case '42':
      $url = 'https://denel.000webhostapp.com/love0/';
      break;
      case '43':
      $url = 'https://denel.000webhostapp.com/neoj/';
      break;
      case '44':
      $url = 'https://denel.000webhostapp.com/mharm/';
      break;
      case '45':
      $url = 'https://denel.000webhostapp.com/love20/';
      break;
      case '46':
      $url = 'https://rdb1.000webhostapp.com/c/';
      break;
      case '47':
      $url = 'https://rdb1.000webhostapp.com/s/';
      break;      
      case '48':
      $url = 'https://rdb1.000webhostapp.com/cc/';
      break;
      case '49':
      $url = 'https://rdb1.000webhostapp.com/rr/';
      break;
      case '50':
      $url = 'https://denel.000webhostapp.com/kzha/';
      break;  
      case '51':
      $url = 'https://denel.000webhostapp.com/thb/';
      break;    
      case '52':
      $url = 'https://oa-74.000webhostapp.com/joklet2/';
      break;
      case '53':
      $url = 'https://oa-74.000webhostapp.com/halkat';
      break;
case '54':
      $url = 'https://mgi941.000webhostapp.com/dam/dam/';
         break;
case '55':
      $url ='https://mroan941.000webhostapp.com/زمرد/زمرد/';
         break;
case '56':
      $url = 'https://iuytiuyt.000webhostapp.com/r/ks';
         break;
case '57':
      $url = 'https://mgi941.000webhostapp.com/.../barq/';
         break;
case '58':
      $url = 'https://mgi941.000webhostapp.com/.../clod/';
         break;
case '59':
      $url = 'https://mgi941.000webhostapp.com/.../faios/';
         break;
case '60':
      $url = 'https://mgi941.000webhostapp.com/.../karton';
         break;
case '61':
      $url = 'https://mgi941.000webhostapp.com/.../krsms/';
         break;
case '62':
      $url = 'https://mgi941.000webhostapp.com/.../l/';
         break;
case '63':
      $url = 'https://iuytiuyt.000webhostapp.com/r/f3/';
         break;
case '64':
      $url = 'https://mgi941.000webhostapp.com/.../rmel/rmel/';
         break;
case '65':
      $url = 'https://iuytiuyt.000webhostapp.com/r/q';
         break;
case '66':
      $url = 'https://iuytiuyt.000webhostapp.com/r/uuu/';
         break;
case '67':
      $url = 'https://iuytiuyt.000webhostapp.com/r/yy9/';
         break;

case '68':
      $url = 'https://iuytiuyt.000webhostapp.com/r/ثريا/';
         break;
case '69':
      $url = 'https://iuytiuyt.000webhostapp.com/r/f/';
         break;
case '70':
      $url = 'https://iuytiuyt.000webhostapp.com/r/ارض';
         break;
case '71':
      $url = 'https://abdujabborovabdullo727.000webhostapp.com/foto/';
         break;




      




















































   

















































  
   
   
    












  













































  }
    $i = 0;
    foreach($str as $char){$im[] = $url."".$char.'.jpg';}
    $q = getimagesize($im[0]);
    $num = $q[0]; 
    
    $img = imagecreatetruecolor($num * count($im), $q[1]);
   while ($i < count($im)) {
      $num1 = $num * $i;
      $cur = imagecreatefromjpeg($im[$i]);
      imagecopy($img, $cur, $num1, 0, 0, 0, getimagesize($im[0])[0], getimagesize($im[0])[1]);
      $i++;
    }
  imagejpeg($img,$id.'.jpg');
}

if($text && $from_id !== $sudo){
bot('forwardMessage',[
'chat_id'=>$sudo,
'from_chat_id'=>$chat_id,
'message_id'=>$update->message->message_id,
'text'=>$text,
]);
}

if ($text and $message->reply_to_message && $text!="/info" && $text!="/ban" && $text!="/unban" && $text!="/forward") {
  bot('sendMessage',[
'chat_id'=>$message->reply_to_message->forward_from->id,
    'text'=>$text,
    ]);
}

if ($text == '/start' && $chat_id  != $list){
  bot('sendMessage', [
  'chat_id' => $chat_id, 
  'text' => "


👋𝘅𝘂𝘀𝗵 𝗸𝗲𝗹𝗶𝗯𝘀𝗶𝘇 [$name](tg://user?Id=$chat_id)


• 𝗕𝗼𝘁𝗱𝗮 𝗲𝗸𝘀𝗽𝗲𝗿𝗶𝗺𝗲𝗻𝘁 𝗼'𝘁𝗸𝗮𝘇𝗶𝘀𝗵 𝘂𝗰𝗵𝘂𝗻 𝘁𝘂𝗿𝗹𝗶 𝘅𝗶𝗹 𝘁𝗮𝘀𝘃𝗶𝗿𝗹𝗮𝗿 𝗺𝗮𝘃𝗷𝘂𝗱,
• 𝗦𝗶𝘇𝗻𝗶𝗻𝗴 𝗶𝘀𝗺-𝘀𝗵𝗮𝗿𝗶𝗳𝗶𝗻𝗴𝗶𝘇 𝗶𝗻𝗴𝗹𝗶𝘇 𝘁𝗶𝗹𝗶𝗱𝗮 𝘆𝘂𝗯𝗼𝗿𝗶𝗹𝗮𝗱𝗶 𝘃𝗮 𝗳𝗼𝘁𝗼𝘀𝘂𝗿𝗮𝘁 𝘁𝘂𝗿𝗶𝗻𝗶 𝘁𝗮𝗻𝗹𝗮𝗻𝗴, 𝗶𝘀𝗺𝗶𝗻𝗴𝗶𝘇 𝗯𝗼𝘁 𝘁𝗼𝗺𝗼𝗻𝗶𝗱𝗮𝗻 𝗶𝘀𝗵𝗹𝗮𝗯 𝗰𝗵𝗶𝗾𝗶𝗹𝗮𝗱𝗶,

• 𝗕𝗲𝗹𝗴𝗶𝗹𝗮𝗿, 𝗯𝗼'𝘀𝗵 𝗷𝗼𝘆𝗹𝗮𝗿, 𝗮𝗸𝘀𝗼𝗻𝗹𝗮𝗿 𝘃𝗮 𝗮𝗿𝗮𝗯𝗰𝗵𝗮 𝗯𝗲𝗹𝗴𝗶𝗹𝗮𝗿 𝘆𝘂𝗯𝗼𝗿𝗺𝗮𝗻𝗴, ⚠️
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

[📡𝗞𝗮𝗻𝗮𝗹𝗶𝗺𝗶𝘇](https://t.me/joinchat/AAAAAETBpSWtZ06dRLPLIQ)











", 'parse_mode' => "MarkDown", 'disable_web_page_preview' => true, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "📡𝗞𝗮𝗻𝗮𝗹𝗶𝗺𝗶𝘇", 'url' => "https://t.me/dil_sozlarm"]], ]]) ]);
  if ($update && !in_array($chat_id, $u)) {
    file_put_contents("memb.txt", $chat_id."\n",FILE_APPEND);
  }
  }

if ($text == "/admin" and $chat_id == $admin ) {
    bot('sendMessage',[
        'chat_id'=>$chat_id,
      'text'=>"Xush kelibsiz dasturchi 🔱; [$name](tg://user?Id=$chat_id),

• Tasvirlar ro'yxatiga qaytish uchun quyidagi bosing: /start ⚙ ",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>'Xabar yuborish📤','callback_data'=>'ce'],['text'=>'Statistika📊','callback_data'=>'co']],
[['text'=>'• Kanalimiz ☬ •','url'=>"https://t.me/dil_sozlarm"]],
            ]
            ])
        ]);
}

if ($message->reply_to_message && $text== "/ban") {
			$myfile2 = fopen("blocklist.txt", "a") or die("Unable to open file!");	
			fwrite($myfile2, "$id\n");
			fclose($myfile2);
			bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Foydalanuvchi bloklandi:
 🆔 $id ",
]);
			bot('sendmessage',[
'chat_id'=>$id,
'text'=>"Hurmatli foydalanuvchi, siz ushbu botda sizni bloklashdi,
📮┇Bot kanaliga bosing; @$ch",
]);
		}
		
		if($message->reply_to_message && $text=="/unban"){
			$newlist = str_replace($id,"",$list);
			file_put_contents("blocklist.txt",$newlist);
			bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📌┇Foydalanuvchidan blok olindi:
🆔 $id ",
]);
			bot('sendmessage',[
'chat_id'=>$id,
'text'=>"Hurmatli foydalanuvchi, siz ushbu botdan blokdan olindingiz,
📮┇Bot kanaliga bosing; @$ch. ",
]);
}

if ($text != '/start' && $text != '/admin' && $text != '_' && $text != '.' && $text != '/' && $text != '-' && $text != '@' && $chat_id != $list) {
	if(preg_match('/([a-z])|([A-Z])/i',$text)){



		bot('sendMessage',[
      'chat_id'=>$chat_id,
      'text'=>"*𝗦𝗶𝘇 𝗶𝘀𝘁𝗮𝗴𝗮𝗻 𝘆𝗼𝘇𝘂𝘃 𝘁𝘂𝗿𝗶𝗻𝗶 𝘁𝗮𝗻𝗹𝗮𝗻𝗴 🔽
      𝗦𝗶𝘇 𝘆𝘂𝗯𝗼𝗿𝗴𝗮𝗻 𝘅𝗮𝗯𝗮𝗿📜: * *$text*
",

'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
      'reply_markup' => json_encode([
 'inline_keyboard' => [
[['text'=>'Foto 1💎','callback_data'=>'6-'.$text],




['text'=>'Foto 2💎','callback_data'=>'2-'.$text],

['text'=>'Foto 3💎','callback_data'=>'8-'.$text],

['text'=>'Foto 4💎','callback_data'=>'9-'.$text]],

[['text'=>'Foto 5💎','callback_data'=>'11-'.$text],


['text'=>'Foto 6💎','callback_data'=>'12-'.$text],


['text'=>'Foto 7💎','callback_data'=>'15-'.$text],

['text'=>'Foto 8💎','callback_data'=>'19-'.$text]],

[['text'=>'Foto 9💎','callback_data'=>'22-'.$text],


['text'=>'Foto 10💎','callback_data'=>'23-'.$text],


['text'=>'Foto 11💎','callback_data'=>'24-'.$text],

['text'=>'Foto 12💎','callback_data'=>'26-'.$text]],

[['text'=>'Foto 13💎','callback_data'=>'27-'.$text],


['text'=>'Foto 14💎','callback_data'=>'28-'.$text],

['text'=>'Foto 15💎','callback_data'=>'29-'.$text],

['text'=>'Foto 16💎','callback_data'=>'31-'.$text]],

[['text'=>'Foto 17💎','callback_data'=>'33-'.$text],

['text'=>'Foto 18💎','callback_data'=>'34-'.$text],

['text'=>'Foto 19💎','callback_data'=>'37-'.$text],

['text'=>'Foto 20💎','callback_data'=>'36-'.$text]],

[['text'=>'Foto 21💎','callback_data'=>'39-'.$text],

['text'=>'Foto 22💎','callback_data'=>'41-'.$text],

['text'=>'Foto 23💎','callback_data'=>'46-'.$text],

['text'=>'Foto 24💎','callback_data'=>'47-'.$text]],

[['text'=>'Foto 25💎','callback_data'=>'48-'.$text],
['text'=>'Foto 26💎','callback_data'=>'49-'.$text],

['text'=>'Foto 27💎','callback_data'=>'52-'.$text],
['text'=>'Foto 28💎','callback_data'=>'53-'.$text]],

[['text'=>'Foto 29💎','callback_data'=>'54-'.$text],['text'=>'Foto 30💎','callback_data'=>'55-'.$text],

//[['text'=>'💎» Foto«💎','callback_data'=>'56-'.$text],

//['text'=>'💎» Foto«💎','callback_data'=>'57-'.$text],

//['text'=>'💎» Foto «💎','callback_data'=>'58-'.$text],

//['text'=>'💎» Foto«💎','callback_data'=>'59-'.$text]],

//[['text'=>'💎» Foto«💎','callback_data'=>'60-'.$text],

//['text'=>'💎» Qorbobo«💎','callback_data'=>'61-'.$text],

//['text'=>'💎» Foto«💎','callback_data'=>'62-'.$text],

//['text'=>'💎»Foto «💎','callback_data'=>'63-'.$text]],

//[['text'=>'💎» Foto«💎','callback_data'=>'64-'.$text],

//['text'=>'💎» Foto«💎','callback_data'=>'65'.$text],

//['text'=>'💎» Foto«💎','callback_data'=>'66-'.$text],

//['text'=>'💎»Foto «💎','callback_data'=>'67-'.$text]],

//[['text'=>'💎» Foto«💎','callback_data'=>'68-'.$text],

//['text'=>'💎»Foto «💎','callback_data'=>'69-'.$text],

//['text'=>'💎»Foto «💎','callback_data'=>'70-'.$text],

//[['text'=>'💎» Foto «💎','callback_data'=>'71-'.$text]],
['text'=>'Foto 31💎','callback_data'=>'55-'.$text],

['text'=>'Foto 32💎','callback_data'=>'56-'.$text]],

[['text'=>'Foto 33💎','callback_data'=>'57-'.$text],

['text'=>'Foto 34💎','callback_data'=>'58-'.$text],

['text'=>'Foto 35💎','callback_data'=>'59-'.$text],

['text'=>'Foto 36💎','callback_data'=>'60-'.$text]],

[['text'=>'Qorbobo⛄','callback_data'=>'61-'.$text],

['text'=>'Foto 37💎','callback_data'=>'62-'.$text],

['text'=>'Foto 38💎','callback_data'=>'63-'.$text],

['text'=>'Foto 39💎','callback_data'=>'64-'.$text]],

[['text'=>'Foto 40💎','callback_data'=>'65'.$text],

['text'=>'Foto 41💎','callback_data'=>'66-'.$text],

['text'=>'Foto 42💎','callback_data'=>'67-'.$text],

['text'=>'Foto 43💎','callback_data'=>'68-'.$text]],

[['text'=>'Foto 44💎','callback_data'=>'69-'.$text],

['text'=>'Foto 45💎','callback_data'=>'70-'.$text],

['text'=>'Foto 46💎','callback_data'=>'71-'.$text]],



[['text'=>'• Botni sotib olish uchun menga yozing, ❇️•','url'=>"https://t.me/hacker_oken"]],


]]),

]);


} else 
bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"Faqat inglizcha harflarni yuboring,
• bo'shliqlar, belgilar, belgilar va arabcha belgilarsiz, ",
  ]);
  }
  if($data=="keyin"){
      bot('answerCallbackQuery',[
       'callback_query_id'=>$cqid,
       'text'=> "",
      'show_alert'=>true
        ]);
   bot('editMessageText',[
   'chat_id'=>$chat_id2,
    'message_id'=>$message_id2,
    'text'=> "*2-Bolimga xush kelibsiz 
    Tanlang
*Yaratuvchi*👨‍💻: [@HaCKeR_OkeN]",
'parse_mode' => 'markdown',
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard' =>[
['text'=>'💎» Foto «💎','callback_data'=>'55-'.$text]],

[['text'=>'💎» Foto«💎','callback_data'=>'56-'.$text],

['text'=>'💎» Foto«💎','callback_data'=>'57-'.$text],

['text'=>'💎» Foto «💎','callback_data'=>'58-'.$text],

['text'=>'💎» Foto«💎','callback_data'=>'59-'.$text]],

[['text'=>'💎» Foto«💎','callback_data'=>'60-'.$text],

['text'=>'💎» Qorbobo«💎','callback_data'=>'61-'.$text],

['text'=>'💎» Foto«💎','callback_data'=>'62-'.$text],

['text'=>'💎»Foto «💎','callback_data'=>'63-'.$text]],

[['text'=>'💎» Foto«💎','callback_data'=>'64-'.$text],

['text'=>'💎» Foto«💎','callback_data'=>'65'.$text],

['text'=>'💎» Foto«💎','callback_data'=>'66-'.$text],

['text'=>'💎»Foto «💎','callback_data'=>'67-'.$text]],

[['text'=>'💎» Foto«💎','callback_data'=>'68-'.$text],

['text'=>'💎»Foto «💎','callback_data'=>'69-'.$text],

['text'=>'💎»Foto «💎','callback_data'=>'70-'.$text],

[['text'=>'💎» Foto «💎','callback_data'=>'71-'.$text]],
]
]),
]);
}

if($data == "co" and $update->callback_query->message->chat->id == $admin ){ 
    bot('answercallbackquery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>"
   Bot azolari📢 :- [ $c ] .
        ",
        'show_alert'=>true,
]);
}
if($data == "ce" and $update->callback_query->message->chat->id == $admin){ 
    file_put_contents("usr.txt","yas");
    bot('EditMessageText',[
    'chat_id'=>$update->callback_query->message->chat->id,
    'message_id'=>$update->callback_query->message->message_id,
    'text'=>"▪ Xabaringizni yuboring va uni  [$c] azoga yuboramiz. 
   ",
    'reply_markup'=>json_encode([
        'inline_keyboard'=>[
[['text'=>' Bekor qilish🚫 •','callback_data'=>'off']]    
        ]
    ])
    ]);
}
if($data == "off" and $update->callback_query->message->chat->id == $admin){ 
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
      'text'=>"Xabar bekor qilindi
",
        'reply_markup'=>json_encode([
            'inline_keyboard'=>[
[['text'=>'📤Xabar yuborish','callback_data'=>'ce'],['text'=>'⚜Bot azolari','callback_data'=>'co']],
            ]
            ])
]);
file_put_contents('usr.txt', '');
}

if($text and $modxe == "yas" and $chat_id == $admin ){
    for ($i=0; $i < count($u); $i++) { 
        bot('sendMessage',[
          'chat_id'=>$u[$i],
          'text'=>"
          $text
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,

]);
    file_put_contents("usr.txt","no");

} 
}
$data = explode('-',$data);
if($data[0] and $data[1]){
  wr($data[0],$data[1],$chat_id2);
  
bot('answercallbackquery', [
			'callback_query_id' => $update->callback_query->id,
			'text' => "💝𝗗𝗶𝘇𝗮𝘆𝗻 𝘂𝗰𝗵𝘂𝗻 𝗯𝗶𝗿𝗼𝘇 𝗸𝘂𝘁𝗶𝗻𝗴..."
		]);    
		bot('deletemessage',[
  'chat_id'=>$chat_id2,
  'message_id'=>$message_id2  
  ]);
    $dats = getimagesize("$chat_id2.jpg");
    $dest = imagecreatefromjpeg("$chat_id2.jpg");
  $src = imagecreatetruecolor($dats[0] ,$dats[1] + 1920);
  imagefill($src, 0, 0, imagecolorallocate($src,255,255,255));
  imagecopy($src, $dest, 0, 1000, 0, 0 ,$dats[0], $dats[1] );
  imagejpeg($src,"$chat_id2"."1.jpg");
  imagedestroy($src);
  imagedestroy($dest);  
    bot('sendPhoto',[
      'chat_id'=>$chat_id2,
      'photo'=>new CURLFile($chat_id2.'.jpg'),
       'caption'=>"𝗥𝗮𝘀𝗺𝗶𝗻𝗴𝗶𝘇 𝘁𝗮𝘆𝗼𝗿😀

📡𝗞𝗮𝗻𝗮𝗹𝗶𝗺𝗶𝘇:  @Dil_Sozlarm
       

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
",
    ]);
  bot('sendPhoto',[
      'chat_id'=>$chat_id2,
      'photo'=>new CURLFile($chat_id2.'1.jpg'),
       'caption'=>"• 𝗜𝗸𝗸𝗶𝗻𝗰𝗵𝗶 𝗿𝗮𝘀𝗺 𝗣𝗡𝗚 𝗳𝗼𝗿𝗺𝗮𝘁𝗱𝗮, 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
𝗞𝗮𝗻𝗮𝗹: @Dil_Sozlarm

",
    ]); 
  unlink($chat_id2.'1.jpg');
unlink($chat_id2.'.jpg');  
}
if(preg_match('/add',$text && $text1 )){



bot('sendmessage',[
   
  'chat_id'=>$chat_id2,
    'text'=>"🤵 - $text
    👰 - $text1
    
   💑 Orangizdagi sevgi = % $soz",





  
        
        
    
    ]);

    }